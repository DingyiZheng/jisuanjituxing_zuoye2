var searchData=
[
  ['next',['next',['../class_c_m_u462_1_1_halfedge.html#a0087a41a23cd154f13b73c7488ac3b53',1,'CGL::Halfedge::next(void)'],['../class_c_m_u462_1_1_halfedge.html#aa65ddedce5c990859c7c9ba8f2e85459',1,'CGL::Halfedge::next(void) const ']]],
  ['normal',['normal',['../class_c_m_u462_1_1_face.html#a33719ad5648aa02a8b47679c86424434',1,'CGL::Face']]]
];
