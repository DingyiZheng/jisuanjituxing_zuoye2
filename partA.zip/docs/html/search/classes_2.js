var searchData=
[
  ['vertex',['Vertex',['../class_c_m_u462_1_1_vertex.html',1,'CGL']]]
];
