var searchData=
[
  ['face',['Face',['../class_c_m_u462_1_1_face.html',1,'CGL']]],
  ['face',['face',['../class_c_m_u462_1_1_halfedge.html#abca92f60b0887f9b580710ee2c2675df',1,'CGL::Halfedge::face(void)'],['../class_c_m_u462_1_1_halfedge.html#a62be6036ae2e45cb7005db06b93cf8dc',1,'CGL::Halfedge::face(void) const '],['../class_c_m_u462_1_1_face.html#a8c063d229c18786287fc1d10ae00356e',1,'CGL::Face::Face()']]]
];
